console.log("test")

// alle benodigde variabelen op een rij onder elkaar
var groet = ['Hallo!', 'Hoihoi', 'Hoi oppas'];
var pElement = document.querySelector('.groet');
var buttonElement = document.querySelector('button');
var bodyElement = document.querySelector('body');
var randomGetal;
var score = 0;
var imgElement = document.querySelector('img');
var broccoliButtonElement = document.querySelector('#broccoli');
var flesjeButtonElement = document.querySelector('#flesje');
var papjeButtonElement = document.querySelector('#papje');
var h3Element = document.querySelector('h3');
var progressElement = document.querySelector ('#vulling');

// array aangemaakt om terug te groeten
function hallo() {
    randomGetal = Math.random() * groet.length;
    randomGetal = Math.floor(randomGetal);
    pElement.textContent = groet[randomGetal];
};

// functie voor broccoli button
function broccoli() {
    imgElement.src = "./img/babybah.png";
    h3Element.textContent = "Toby vindt broccoli niet lekker, probeer wat anders.."
    // het element dat ervoor zorgt dat de waarde van de progressbar veranderd bij klik op de button
    progressElement.value += -10;
}

// functie voor flesje button
function flesje() {
    imgElement.src = "./img/babyblij.png";
    h3Element.textContent = "Toby vindt zijn flesje heerlijk, goede keuze gemaakt!"
    progressElement.value += 15;

    // functie if/else, als je 3 keer of meer op de knop drukt krijg je ander beeld op het scherm
    score+= 1;
    console.log(score);

    if (score < 3) {
        console.log('Flesje')
        h3Element.textContent = "Toby is blij met je keuze van het flesje."
        imgElement.src = "./img/babyblij.png";
    } else if (score == 3) {
        console.log("Toby zit vol!");
        h3Element.textContent = "Toby heeft genoeg gehad van zijn flesje, hij zit erg vol en wilt niet meer."
        imgElement.src = "./img/babybah.png";
    }
}

// functie voor papje button
function papje() {
    imgElement.src = "./img/babydroevig.png";
    h3Element.textContent = "Toby vindt pap niet zo lekker, probeer wat anders.."
    progressElement.value += 5;
}


// aanroepen van functie wanneer je op de button klikt
buttonElement.addEventListener('click', hallo);

broccoliButtonElement.addEventListener('click', broccoli)
flesjeButtonElement.addEventListener('click', flesje)
papjeButtonElement.addEventListener('click', papje)
